package by.damenikan.line.action;

public class Disatnce {

}
