package by.damenikan.line.action;

public class Angle {

}
